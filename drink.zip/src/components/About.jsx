import React from 'react'
import Navbar from './Navbar'

const About = () => {
    return (
        <div>
            <Navbar/>
            <div className="containetAbout">
                <div className="rowAbout">
                    <h1>Hello About</h1>
                    <p className="lorem">Lorem ipsum dolor sit amet consectetur adipisicing elit. Sapiente enim nulla nemo nostrum facere quia earum libero eaque autem, praesentium, possimus sit veritatis molestias incidunt hic nisi dolor? Voluptatibus eius vitae neque, nisi iusto reiciendis sequi, accusantium voluptas minima dolore magnam adipisci atque? Magnam aspernatur provident cupiditate eos maiores ex sed excepturi dolores quo distinctio maxime deserunt minima in iure voluptas nisi placeat voluptates tempora, doloremque voluptate, fugit est? Quos nam corrupti repellat? Officiis iste commodi, adipisci eligendi unde quia perferendis ab molestiae! Eum deleniti vel facere eius suscipit eos eaque alias! Ea, error. Labore totam eius impedit, aperiam pariatur ullam exercitationem praesentium fugiat qui ex recusandae? Odit eius dolor dolores! Natus quam minima possimus cum eius, voluptates doloribus sunt consequatur tempore omnis eveniet voluptate tempora est perspiciatis fugiat quis! Quam, ex sint! Molestias repellendus labore quo nobis facere, eligendi enim corrupti aliquam unde, earum numquam excepturi eius voluptate facilis blanditiis eaque explicabo quia nihil natus. Laboriosam molestiae corporis doloremque in vel, deleniti facilis perspiciatis facere libero ex dolore vero fuga sunt, aspernatur eveniet! Consequatur nam dolorum quis doloribus deleniti soluta aliquid eligendi quas quod libero blanditiis laborum, tempore deserunt necessitatibus laudantium rem alias accusamus nisi quibusdam ut! Reprehenderit impedit voluptas totam odio delectus, voluptate eaque iusto vel aspernatur molestias. Dolor, mollitia nulla! Quas officiis illo nobis cumque? Molestias ipsam quas odit, nostrum esse a dolorem fugiat nihil culpa ex iste saepe qui quo officia pariatur tempore itaque. Eum et repellat earum unde ipsum reprehenderit laboriosam est fuga eligendi autem ea optio debitis, ex consectetur! Eveniet reiciendis, eligendi facere dolores quos tempore. Accusantium, dolorum ut. Accusamus quaerat aliquid consectetur, obcaecati dicta et illum eum ex quidem debitis veniam tempora maxime rem sed ut velit aut quasi? Ducimus optio unde earum molestias doloribus placeat inventore error ipsa, natus quisquam accusamus iusto dolorum? Sapiente, sequi accusamus unde, quod ab suscipit earum deleniti repellendus omnis dolor laudantium necessitatibus, consequatur dolorem eum minus odio iusto totam quisquam quasi voluptates debitis aliquam quidem ea ullam. At excepturi cupiditate voluptate hic placeat tempore magni quas, laboriosam sit praesentium porro perspiciatis similique officia odit sapiente inventore accusamus a necessitatibus optio quis laborum eos minus reprehenderit! Incidunt, minima.</p>
                </div>
            </div>
        </div>
        
    )
}

export default About
